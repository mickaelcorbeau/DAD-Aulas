<?php $__env->startSection('title', 'Add department'); ?>

<?php $__env->startSection('content'); ?>

<?php if(count($errors) > 0): ?>
    <?php echo $__env->make('shared.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<form action="<?php echo e(route('departments.store')); ?>" method="post" class="form-group">
    <?php echo $__env->make('departments.partials.add-edit', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="form-group">
        <button type="submit" class="btn btn-primary" name="ok">Add</button>
        <a type="submit"  class="btn btn-default" href="<?php echo e(route('departments.index')); ?>">Cancel</a>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>