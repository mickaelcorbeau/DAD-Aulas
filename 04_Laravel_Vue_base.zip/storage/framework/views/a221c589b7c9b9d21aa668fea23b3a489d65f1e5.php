<div class="container-fluid">
    <a class="btn btn-default navbar-btn" href="<?php echo e(route('users.index')); ?>">Users</a>
    <a class="btn btn-default navbar-btn" href="<?php echo e(route('users.index.table')); ?>">Users (DataTable)</a>
    <a class="btn btn-default navbar-btn" href="<?php echo e(route('departments.index')); ?>">Departments</a>
</div>