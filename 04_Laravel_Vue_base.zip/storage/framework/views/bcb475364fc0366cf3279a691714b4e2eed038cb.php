<?php $__env->startSection('title', 'Show user'); ?>

<?php $__env->startSection('content'); ?>

<?php if(count($errors) > 0): ?>
    <?php echo $__env->make('shared.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<div class="form-group">
    <label for="inputName">Name</label>
    <input
        type="text" class="form-control"
        name="name" id="inputName" readonly="readonly"
        placeholder="Fullname" value="<?php echo e($user->name); ?>" />
</div>
<div class="form-group">
    <label for="inputEmail">Email</label>
    <input
        type="email" class="form-control"
        name="email" id="inputEmail" readonly="readonly"
        placeholder="Email address" value="<?php echo e($user->email); ?>"/>
</div>
<div class="form-group">
    <label for="inputAge">Age</label>
    <input
        type="number" class="form-control"
        name="age" id="inputAge" readonly="readonly"
        placeholder="Age" value="<?php echo e($user->age); ?>"/>
</div>
<div class="form-group">
    <label for="department_id">Department:</label>
    <select class="form-control" id="department_id" name="department_id"
            value="<?php echo e(old('department_id', $user->department_id)); ?>" disabled="disabled">
        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($department->id == $user->department_id): ?>
                <option value="<?php echo e($department->id); ?>" selected><?php echo e($department->name); ?></option>
            <?php else: ?>
                <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>