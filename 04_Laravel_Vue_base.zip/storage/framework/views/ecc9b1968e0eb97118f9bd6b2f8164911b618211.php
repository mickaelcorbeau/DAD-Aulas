<?php $__env->startSection('title', 'Vue.js App'); ?>

<?php $__env->startSection('content'); ?>

<div class="jumbotron">
    <h1></h1>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Age</th>
            <th>Department</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        
    </tbody>
</table>

<div class=" alert alert-success">
    <button type="button" class="close-btn" >&times;</button>
    <strong></strong>
</div>

<div class="jumbotron">
    <h2>Edit User</h2>

</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
<script src="js/vue.js"></script>
<?php $__env->stopSection(); ?>  

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>