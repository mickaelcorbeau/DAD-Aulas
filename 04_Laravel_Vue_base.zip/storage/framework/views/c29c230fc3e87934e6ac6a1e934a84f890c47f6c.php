<?php $__env->startSection('title', 'Edit user'); ?>

<?php $__env->startSection('content'); ?>

<?php if(count($errors) > 0): ?>
    <?php echo $__env->make('shared.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<form method="post" class="form-group">
    <?php echo $__env->make('users.partials.add-edit', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="form-group">
        <button type="button" class="btn btn-primary" name="ok" id="btnSave">Save</button>
       <a type="button"  class="btn btn-default" id="btnCancel">Cancel</a>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    <script src="/js/users_edit.js"></script>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>