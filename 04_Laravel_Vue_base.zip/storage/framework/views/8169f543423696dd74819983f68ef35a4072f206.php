<?php $__env->startSection('metatags'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrastyles'); ?>
<link href="https://unpkg.com/vanilla-datatables@latest/dist/vanilla-dataTables.min.css" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'List users'); ?>

<?php $__env->startSection('content'); ?>

<div><a class="btn btn-primary" href="<?php echo e(route('users.create')); ?>">Add user</a></div>

<div class="container">
	<table class="table table-striped" id="dataTable"></table>	
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
<!--     <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
 -->    
	<script src="https://unpkg.com/axios/dist/axios.min.js"></script>
 	<script src="https://unpkg.com/vanilla-datatables@latest/dist/vanilla-dataTables.min.js" type="text/javascript"></script>
	<script src="/js/users_table.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>