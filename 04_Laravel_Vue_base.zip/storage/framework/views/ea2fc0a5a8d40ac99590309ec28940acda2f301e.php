<?php $__env->startSection('metatags'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'List departments'); ?>

<?php $__env->startSection('content'); ?>

<div><a class="btn btn-primary" href="<?php echo e(route('departments.create')); ?>">Add department</a></div>

<?php if(count($departments)): ?>
    <table class="table table-striped">
    <thead>
        <tr>
            <th>Name</th>
            <th>Created</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
    </table>
<?php else: ?>
    <h2>No departments found</h2>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script src="/js/departments.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>