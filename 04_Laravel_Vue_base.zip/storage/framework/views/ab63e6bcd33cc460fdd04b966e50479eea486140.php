<?php $__env->startSection('metatags'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'List users'); ?>

<?php $__env->startSection('content'); ?>

<div><a class="btn btn-primary" href="<?php echo e(route('users.create')); ?>">Add user</a></div>

<?php if(count($users)): ?>
    <table class="table table-striped">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Age</th>
            <th>Department</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>    
    </tbody>
    </table>
    <div id="containerNav" class="pagination">
    </div>
<?php else: ?>
    <h2>No users found</h2>
<?php endif; ?>
<?php $__env->startSection('pagescript'); ?>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script src="/js/users.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>