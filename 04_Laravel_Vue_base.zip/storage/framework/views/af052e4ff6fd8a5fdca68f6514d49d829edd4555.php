<?php $__env->startSection('title', 'Vue.js App'); ?>

<?php $__env->startSection('content'); ?>

<users></users>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
<script src="js/vue.js"></script>
<?php $__env->stopSection(); ?>  

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>