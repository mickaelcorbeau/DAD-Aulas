/*jshint esversion: 6 */

/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');

const userListComponent = Vue.component('user-list', require('./components/userList.vue'));
const userEditComponent = Vue.component('user-edit', require('./components/editUser.vue'));
const usersComponent = Vue.component('users', require('./components/users.vue'));

const app = new Vue({
    el: '#app',
    
    
});
