@extends('master')

@section('title', 'Vue.js App')

@section('content')

<users></users>
@endsection
@section('pagescript')
<script src="js/vue.js"></script>
@stop  
